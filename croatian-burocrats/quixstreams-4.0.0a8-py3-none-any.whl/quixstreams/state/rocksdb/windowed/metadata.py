LATEST_EXPIRED_WINDOW_CF_NAME = "__expiration-index__"
LATEST_EXPIRED_WINDOW_TIMESTAMP_KEY = b"__expired_start_gt__"

LATEST_DELETED_WINDOW_CF_NAME = "__deletion-index__"
LATEST_DELETED_WINDOW_TIMESTAMP_KEY = b"__deleted_start_gt__"

LATEST_DELETED_VALUE_CF_NAME = "__value-deletion-index__"
LATEST_DELETED_VALUE_TIMESTAMP_KEY = b"__value_deleted_start_gt__"

VALUES_CF_NAME = "__values__"
