class QuixException(Exception):
    pass
